<?php
// Text
$_['text_title']	= 'Credit Card';
$_['text_tash'] = 'Payments number';

$_['error_yaadpay_begin'] = 'YaadPay gateway payment return the next error: ';
$_['error_yaadpay_4'] = 'Refusal';
$_['error_yaadpay_6'] = 'A Error in an identity card';
$_['error_yaadpay_3'] = 'Call the credit company';
$_['error_yaadpay_902'] = 'error Referr';
$_['error_yaadpay_36'] = 'Expired';
$_['error_yaadpay_33'] = 'Card Error';

$_['error_yaadpay_unknow'] = 'Error unknow';

$_['error_yaadpay_security'] = 'HASH security error';