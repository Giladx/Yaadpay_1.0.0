# Yaadpay.7.x.x.x
Opencart 3.x extension for Yaadpay Israeli credit clearing services.

![יעד](https://yaadpay.yaad.net/wp-content/uploads/2015/06/Yaad_Sarig_new-_for-web_fin-01.png)

[YaadPay_Website](https://yaadpay.yaad.net/)

![Image](https://github.com/Giladx/Yaadpay_1.0.0/blob/master/yaadpay.png)

