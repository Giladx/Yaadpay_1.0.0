<?php
// Text
$_['text_title']	= 'כרטיס אשראי';
$_['text_tash'] = 'מספר תשלום';

$_['error_yaadpay_begin'] = 'ישנה שגיאה מהספק ';
$_['error_yaadpay_4'] = 'סרוב';
$_['error_yaadpay_6'] = 'שגיאה במספאר הכרטיס';
$_['error_yaadpay_3'] = 'יש להתקשר לחברת האשראי';
$_['error_yaadpay_902'] = 'שגיאה בהפניה';
$_['error_yaadpay_36'] = 'פג תוקף';
$_['error_yaadpay_33'] = 'שגיאה בכרטיס';

$_['error_yaadpay_unknow'] = 'שגיאה לא ידועה';

$_['error_yaadpay_security'] = 'HASH שגיאת אבטחה';
