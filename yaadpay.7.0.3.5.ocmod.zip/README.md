# Yaadpay_1.0.0
Opencart 3.0.x.x extension for Yaadpay Israeli credit clearing services.

[YaadPay_Website](https://yaadpay.yaad.net/)

![Image](https://github.com/Giladx/Yaadpay_1.0.0/blob/master/yaadpay.png)

